import math
class Delivery:
    def __init__(self, description, priority, x, y):
        self.description = description
        self.priority = priority
        self.x = x
        self.y = y
    def distance_to(self, other):
        return math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2)
    def __str__(self):
        return f"{self.description} (Priority: {self.priority}, Location: ({self.x}, {self.y}))"
def sort_deliveries(deliveries):
    priority_map = {'high': 1, 'medium': 2, 'low': 3}
    return sorted(deliveries, key=lambda d: priority_map[d.priority])
def tsp_dynamic_programming(deliveries):
    n = len(deliveries)
    dist = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i != j:
                dist[i][j] = deliveries[i].distance_to(deliveries[j])
    dp = [[float('inf')] * n for _ in range(1 << n)]
    dp[1][0] = 0  
    for mask in range(1 << n):
        for i in range(n):
            if mask & (1 << i): 
                for j in range(n):
                    if not mask & (1 << j):
                        new_mask = mask | (1 << j)
                        dp[new_mask][j] = min(dp[new_mask][j], dp[mask][i] + dist[i][j])
    min_distance = float('inf')
    final_mask = (1 << n) - 1
    for i in range(1, n):
        min_distance = min(min_distance, dp[final_mask][i] + dist[i][0])
    return min_distance
def reconstruct_route(dp, dist, n):
    route = []
    mask = (1 << n) - 1
    last_visited = 0
    for i in range(n - 1, -1, -1):
        route.append(last_visited)
        next_location = -1
        for j in range(n):
            if mask & (1 << j) and dp[mask][last_visited] == dp[mask ^ (1 << last_visited)][j] + dist[j][last_visited]:
                next_location = j
                break
        mask ^= (1 << next_location)
        last_visited = next_location
    route.reverse()
    return route
def main():
    n = int(input("Enter the number of deliveries: "))
    deliveries = []
    for i in range(n):
        description = input(f"Enter description for delivery {i + 1}: ")
        priority = input(f"Enter priority (high, medium, low) for delivery {i + 1}: ")
        x, y = map(float, input(f"Enter the coordinates (x, y) for delivery {i + 1}: ").split())
        deliveries.append(Delivery(description, priority, x, y))
    sorted_deliveries = sort_deliveries(deliveries)
    print("\nSorted Deliveries (by Priority):")
    for i, delivery in enumerate(sorted_deliveries, 1):
        print(f"{i}. {delivery}")
    min_distance = tsp_dynamic_programming(sorted_deliveries)
    print(f"\nTotal Distance: {min_distance:.2f} units")
    n = len(sorted_deliveries)
    dist = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i != j:
                dist[i][j] = sorted_deliveries[i].distance_to(sorted_deliveries[j])
    dp = [[float('inf')] * n for _ in range(1 << n)]
    dp[1][0] = 0
    for mask in range(1 << n):
        for i in range(n):
            if mask & (1 << i):
                for j in range(n):
                    if not mask & (1 << j):
                        new_mask = mask | (1 << j)
                        dp[new_mask][j] = min(dp[new_mask][j], dp[mask][i] + dist[i][j])
    route = reconstruct_route(dp, dist, n)
    print("\nOptimized Delivery Route:")
    for idx in route:
        print(f"{sorted_deliveries[idx].description} at Location ({sorted_deliveries[idx].x}, {sorted_deliveries[idx].y})")
main()
