from datetime import datetime
class Event:
    def __init__(self, description, start, end):
        self.description = description
        self.start = self.time_to_minutes(start)
        self.end = self.time_to_minutes(end)
    def time_to_minutes(self, time_str):
        time_obj = datetime.strptime(time_str, "%H:%M")
        return time_obj.hour * 60 + time_obj.minute
    def __str__(self):
        return f'"{self.description}", Start: "{self.minutes_to_time(self.start)}", End: "{self.minutes_to_time(self.end)}"'
    def minutes_to_time(self, minutes):
        return f"{minutes // 60:02}:{minutes % 60:02}"
def detect_conflicts(events):
    conflicts = []
    for i in range(len(events)):
        for j in range(i + 1, len(events)):
            if (events[i].start < events[j].end and events[i].end > events[j].start):
                conflicts.append((events[i], events[j]))
    return conflicts
def suggest_resolutions(conflicting_events):
    resolutions = []
    for event1, event2 in conflicting_events:
        resolution_time = event1.end
        new_start = event1.minutes_to_time(resolution_time)
        new_end = event1.minutes_to_time(resolution_time + (event2.end - event2.start))
        resolutions.append(f"Reschedule \"{event2.description}\" to Start: {new_start}, End: {new_end}")
    return resolutions
def main():
    events_data = [
        ("Meeting A", "09:00", "10:30"),
        ("Workshop B", "10:00", "11:30"),
        ("Lunch Break", "12:00", "13:00"),
        ("Presentation C", "10:30", "12:00")
    ]
    events = [Event(description, start, end) for description, start, end in events_data]
    events.sort(key=lambda event: event.start)
    print("Sorted Schedule:")
    for i, event in enumerate(events, 1):
        print(f"{i}. {event}")
    conflicts = detect_conflicts(events)
    if conflicts:
        print("\nConflicting Events:")
        for event1, event2 in conflicts:
            print(f"{event1.description} and {event2.description}")
        resolutions = suggest_resolutions(conflicts)
        print("\nSuggested Resolutions:")
        for resolution in resolutions:
            print(resolution)
    else:
        print("\nNo conflicts detected.")
main()